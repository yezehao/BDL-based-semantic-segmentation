# Ocean AI Segmentation Initiatives (OASIs) dataset
Introducing the Ocean AI Segmentation Initiatives(OASI) dataset for the research and evaluation of marine AI models. This dataset enables the evaluation of issues arising from light reflection, interference and various weather conditions. By providing a wide range of ocean images under diverse environmental conditions, OASI aims to evaluate the performance of AI systems in realistic and complex scenarios encountered in marine environments.

## Description of the dataset

This dataset includes a wide range of images captured from various maritime environments and is categorized into three types:

* Type-1: Day-Time Environment
* Type-2: Adverse Weather Environment
* Type-3: Night-Time Environment

The images in the OASIs dataset vary in resolution, ranging from 1280×720 to 4032×3024 pixels. The dataset is labeled by experts. The images provided to the experts are selected from real-time captures that meet specific quality standards. This labeling process is consistently performed at the pixel level according to internally established guidelines.

<table style="border: 2px;">
  <tr>
    <td colspan="3" align="center"> Annotated colors in each label 
 </td>
  </tr><tr>
    <td align="center"> Class </td>
    <td align="center"> Grayscale </td>
  </tr><tr>
    <td align="center"> Others </td>
    <td align="center"> 0 </td>
  </tr><tr>
    <td align="center"> Sky </td>
    <td align="center"> 50 </td>
  </tr><tr>
    <td align="center"> Land </td>
    <td align="center"> 100 </td>
  </tr>
  <tr>
    <td align="center"> Sea Objects </td>
    <td align="center"> 150 </td>
    </tr>
</table>
Semantic segmentation labels of OASIs are annotated to provide pixel-level classification, where each pixel in an image is assigned a Grayscale label corresponding to a particular class.


### The dataset is organized into the following structure:
```
ROOT/
├── TYPE1/
│   ├── image/
│   │   ├── type1_000.png
│   │   ├── type1_001.png
│   │   └─── ...
│   ├── mask/
│   │   ├── type1_000.png
│   │   ├── type1_001.png
│   │   └─── ...
├── TYPE2/
│   ├── image/
│   │   ├── type2_000.png
│   │   ├── type2_001.png
│   │   └─── ...
│   ├── mask/
│   │   ├── type2_000.png
│   │   ├── type2_001.png
│   │   └─── ...
├── TYPE3/
│   ├── image/
│   │   ├── type3_000.png
│   │   ├── type3_001.png
│   │   └─── ...
│   ├── mask/
│   │   ├── type3_000.png
│   │   ├── type3_001.png
│   │   └─── ...
└── README.md

```

#### Description
* TYPE1/: Contains raw images and annotated masks for the TYPE1.
  * image/ Contains the raw images.
    - type1_000.png: The first image of TYPE1.
    - type1_001.png: The second image of TYPE1.
    - ...: Additional images.

* mask/: Contains the corresponding annotated masks for TYPE1 images.
  - type1_000.png: The mask for the first image of TYPE1.
  - type1_001.png: The mask for the second image of TYPE1.
  - ...: Additional masks.
* ...
* README.md: This file providing an overview of the dataset and folder structure.

## Licensing 
The datasets are released under the MIT license, ensuring open access and use with proper attribution. 


## Learn More
For more details and access to the OASIs dataset, see our [white paper](https://arxiv.org/abs/2407.09005)._
